package quanlithuvien;

import java.util.ArrayList;
import java.util.Scanner;

public class HienThi {
	public void MenuAdMin()
	{
		ChucNang cn = new ChucNang();
		while(true)
		{
			try {	
				System.out.println("_________________________________");
				System.out.println("______________Menu_TK ADMIN_____________________");
				System.out.println("1 -Danh sách sách có trong thư viện             |");
				System.out.println("2 -Thêm sách mới vào thư viện                   |");
				System.out.println("3 -Sửa thông tin sách                           |");
				System.out.println("4 -Danh sách người mượn sách                    |");
				System.out.println("5 -Xóa Sách có trong thư viện                   |");
				System.out.println("6 -Danh sách hàng tồn còn trong thư viện        |");
				System.out.println("7 -Bổ sung số lượng sách có trong thư viện      |");
				System.out.println("8 _Tìm kiếm người mượn sách                     |");
				System.out.println("9 -Đăng xuất                                    |");
				System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
				System.out.print("chọn>>>>>>");
				Scanner sc0 = new Scanner(System.in);
				int x = sc0.nextInt();
				String pt = "C:\\Users\\TUAN ANH\\Documents\\Code\\quanlythuvien\\dsSach.txt";
				String pt_sv = "C:\\Users\\TUAN ANH\\Documents\\Code\\quanlythuvien\\dsSinhVien.txt";
				String pt_ton = "C:\\Users\\TUAN ANH\\Documents\\Code\\quanlythuvien\\dsSachton.txt";
				Docfile df = new Docfile(pt);
				ArrayList<String> check = (ArrayList<String>) df.DocFiletxt();
				if (x == 1) {
					cn.LkSachTrongThuVien(pt);
				} else if (x == 2) {
					cn.ThemSachVaoThuVien(pt,pt_ton);
				}else if( x == 3){	
					cn.SuaThongTinSach(pt);
				}else if(x == 4){
					cn.LkDanhSachSvMuonSach(pt_sv);
				}else if(x == 5) {
					cn.XoaSachTrongThuVien(pt,pt_ton);
				}else if(x == 6){
					cn.LietKeDanhSachHangTon(pt_ton);
				}else if(x == 7) {
					cn.BoSungSoLuong(pt_ton);
				}else if( x == 9)
				{
					System.out.println("Close programme !");
					break;
				}
				else if(x == 8)
				{
					cn.TimKiemNguoiMuon(pt_sv);
				}
			} catch (Exception e) {
				System.out.println("");
			}
		}
	}
	public void MenuNguoiDung()
	{
		
		ChucNang cn = new ChucNang();
		QuanLiFile ql = new QuanLiFile();
		while(true)
		{
			try {	
				System.out.println("_________________________________");
				System.out.println("______________Menu_TK_Thành_Viên_________________");
				System.out.println("1 -Danh sách sách có trong thư viện              |");
				System.out.println("2 -Danh sách số lượng còn trong thư viện         |");
				System.out.println("3 -Tìm kiếm sách                                 |");
				System.out.println("4 -MƯỢN SÁCH                                     |");
				System.out.println("5 -TRẢ SÁCH                                      |");
				System.out.println("6-Đăng Xuất                                      |");
				System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
				Scanner sc1 = new Scanner(System.in);
				System.out.print("chọn>>>>>");
				int x = sc1.nextInt();
				String pt = ql.getfDsSach();
				String pt_sv = ql.getfDsSinhVien();
				String pt_ton =ql.getfDsHangTon();
				if (x == 1) {
					cn.LkSachTrongThuVien(pt);
				}else if(x == 2){
					cn.LietKeDanhSachHangTon(pt_ton);
				}else if(x == 3)
				{
					cn.TimKiem(pt);
				}
				else if(x == 4){
					cn.muonSach(pt, pt_ton, pt_sv);
				}else if( x== 5)
				{
					cn.traSach(pt, pt_sv, pt_ton);
				}
				else if( x == 6)
				{
					System.out.println("Close programme !");
					break;
				}
			} catch (Exception e) {
				System.out.println("");
			}
		}
	}
	public void HienThiTongQuat()
	{
		HienThi ht = new HienThi();
		ChucNang cn = new ChucNang();
		while(true)
		{
			try {
				System.out.println("___________________");
				System.out.println("1-Đăng kí         |");
				System.out.println("2-Đăng nhập       |");
				System.out.println("3-Quên mật khẩu   |");
				System.out.println("4-Thoát           |");
				System.out.println("^^^^^^^^^^^^^^^^^^^");
				System.out.print("Chọn>>>>>>>");
				Scanner sc = new Scanner(System.in);
				int z = sc.nextInt();
				if(z == 1)
				{
					cn.Dangki();
				}
				if(z == 2)
				{
					String k = cn.Dangnhap();
					if(k == "ADMIN")
					{
						ht.MenuAdMin();
					}else if(k == "nguoi_dung")
					{
						ht.MenuNguoiDung();
					}
				}
				if(z == 3)
				{
					cn.QuenMatKhau();
				}
				if(z == 4)
				{
					System.out.println("Close!");
					break;
				}
			} catch (Exception e) {
				System.out.println("ERROR!");
			}
		}
	}
}
