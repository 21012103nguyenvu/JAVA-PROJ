package quanlithuvien;

public class QuanLiFile {
	public String fDsSach= "C:\\Users\\TUAN ANH\\Documents\\Code\\quanlythuvien\\dsSach.txt";
	public String  fDsSinhVien= "C:\\Users\\TUAN ANH\\Documents\\Code\\quanlythuvien\\dsSinhVien.txt";
	public String fDsHangTon ="C:\\Users\\TUAN ANH\\Documents\\Code\\quanlythuvien\\dsSachton.txt";
	public String fDsTaiKhoanTv = "C:\\Users\\\\TUAN ANH\\Documents\\Code\\quanlythuvien\\dsTK.txt";
	public String fDsTaiKhoanAd = "C:\\Users\\\\TUAN ANH\\Documents\\Code\\quanlythuvien\\dsTKAD.txt";
	public String getfDsSach() {
		return fDsSach;
	}
	public void setfDsSach(String fDsSach) {
		this.fDsSach = fDsSach;
	}
	public String getfDsSinhVien() {
		return fDsSinhVien;
	}
	public void setfDsSinhVien(String fDsSinhVien) {
		this.fDsSinhVien = fDsSinhVien;
	}
	public String getfDsHangTon() {
		return fDsHangTon;
	}
	public void setfDsHangTon(String fDsHangTon) {
		this.fDsHangTon = fDsHangTon;
	}
	public String getfDsTaiKhoanTv() {
		return fDsTaiKhoanTv;
	}
	public void setfDsTaiKhoanTv(String fDsTaiKhoanTv) {
		this.fDsTaiKhoanTv = fDsTaiKhoanTv;
	}
	public String getfDsTaiKhoanAd() {
		return fDsTaiKhoanAd;
	}
	public void setfDsTaiKhoanAd(String fDsTaiKhoanAd) {
		this.fDsTaiKhoanAd = fDsTaiKhoanAd;
	}
	
}
