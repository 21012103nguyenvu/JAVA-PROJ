package quanlithuvien;

public class TaiKhoan {
	private String tk;
	private String mk;
	private long sdt;
	TaiKhoan(String tk , String mk,long sdt)
	{
		this.tk = tk;
		this.mk = mk;
		this.sdt = sdt;
	}
	public long getSdt() {
		return sdt;
	}
	public void setSdt(long sdt) {
		this.sdt = sdt;
	}
	public String getTk() {
		return tk;
	}
	public void setTk(String tk) {
		this.tk = tk;
	}
	public String getMk() {
		return mk;
	}
	public void setMk(String mk) {
		this.mk = mk;
	}
	@Override
	public String toString() {
		return tk +","+ mk+","+sdt;
	}
}
