package quanlithuvien;

public class Sach {
	private String id;
	private String name;
	private String tacgia;
	private int namxuatban;
	private String nguoiMuon;
	Sach(String id,String name,String tacgia,int namxuatban)
	{
		this.id = id;
		this.name = name;
		this.tacgia = tacgia;
		this.namxuatban = namxuatban;
		this.nguoiMuon = null;
	}
	Sach(String id,String name,String tacgia,int namxuatban,String nguoiMuon)
	{
		this.id = id;
		this.name = name;
		this.tacgia = tacgia;
		this.namxuatban = namxuatban;
		this.nguoiMuon = nguoiMuon;
	}

	public String getNguoiMuon() {
		return nguoiMuon;
	}
	public void setNguoiMuon(String nguoiMuon) {
		this.nguoiMuon = nguoiMuon;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTacgia() {
		return tacgia;
	}
	public void setTacgia(String tacgia) {
		this.tacgia = tacgia;
	}
	public int getNamxuatban() {
		return namxuatban;
	}
	public void setNamxuatban(int namxuatban) {
		this.namxuatban = namxuatban;
	}
	@Override
	public String toString() {
		return  id +"," + name +"," + tacgia +","+ namxuatban
				+","+ nguoiMuon;
	}
	public String toString1() {
		return  id +"," + name +"," + tacgia +","+ namxuatban;
	}
	
}
