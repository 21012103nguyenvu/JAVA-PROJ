package quanlithuvien;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.print.Doc;

public class Thuvien {
	public static void main(String[] args) {
		System.setProperty("file.encoding", "UTF-8");
		PrintStream out;
		try {
			out = new PrintStream(System.out, true, "UTF-8");
			System.setOut(out);

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HienThi ht = new HienThi();
		ht.HienThiTongQuat();
	}
}
