package quanlithuvien;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

import javax.print.Doc;
public class ChucNang {
	 public static boolean isFileEmpty(String filePath) throws IOException {//hàm kiểm tra file rỗng
	        File file = new File(filePath);
	        if (file.length() == 0) {
	            return true;
	        }
	        return false;
	    }
	 public int SoSanhDate(String date1, String date2)
	 {
		 
		 String[] list1 = date1.split("/");
		 String[] list2 = date2.split("/");
		 int year1 = Integer.valueOf(list1[2]);
		 int year2 = Integer.valueOf(list2[2]);
		 int month1 = Integer.valueOf(list1[1]);
		 int month2 = Integer.valueOf(list2[1]);
		 int day1 = Integer.valueOf(list1[0]);
		 int day2= Integer.valueOf(list2[0]);
		 if(year1 > year2)
		 {
			 return 1;
		 }else if(year1 < year2)
		 {
			 return -1;
		 }else
		 {
			 if(month1 > month2)
			 {
				 return 1;
			 }else if(month1 < month2)
			 {
				 return -1;
			 }else
			 {
				 if(day1 > day2)
				 {
					 return 1;
				 }else if(day1< day2)
				 {
					 return -1;
				 }else
				 {
					 return 0;
				 }
			 }
		 }
	 }
	public String MaId(String s) {//hàm lấy String trc dấu "," đầu tiên
		String check = "";
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == ',' && s.charAt(i) != 0) {
				break;
			}
			check += s.charAt(i);
		}
		return check;
	}

	public String Phay2(String s) {//hàm lấy string sau dấy "," đầu tiên
		String check = "";
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == ',') {
				for (int j = i + 1; j < s.length(); j++) {
					if (s.charAt(j) == ',') {
						break;
					}
					check += s.charAt(j);
				}
				break;
			}
		}
		return check;
	}

	public void LkSachTrongThuVien(String pt) {
		Thuvien tv = new Thuvien();
		Docfile df = new Docfile(pt);
		System.out.println("|--------------------------------------------------------------------------------------------------------|");
		System.out.format("%-15s %-40s %-30s %-7s \n", "|MÃ SÁCH", "TÊN SÁCH", "TÊN TÁC GIẢ", "NĂM XUẤT BẢN");
		System.out.println("|--------------------------------------------------------------------------------------------------------|");
		ArrayList<String> check = (ArrayList<String>) df.DocFiletxt();
		// Xử lí lỗi kí tự khoảng trong file khi thêm dữ liệu vào file
		String kList = "";
		int count = 0;
		for (String c : check) {
			kList += c + ";";
			count++;
		}

		String[] listList = kList.split(";");// ngắt string bằng kí tự ";" rồi add vào mảng listList
		for (int i = 0; i < count; i++) {
			if (!listList[i].equals("")) {
				// ngắt String bằng kí tự "," , rồi cho vào mảng
				String[] list = listList[i].split(",");
				String msach = list[0];
				String tenSach = list[1];
				String tenTacGIa = list[2];
				String namxb = list[3];
				// in thông tin ra theo 1 form nhất định
				System.out.format("%-15s %-40s %-30s %-7s \n", "|" + msach, tenSach, tenTacGIa, namxb);
				System.out.println("|--------------------------------------------------------------------------------------------------------|");
			}

		}
	}

	public void ThemSachVaoThuVien(String pt, String pt_ton) {
		try {
			Scanner sc = new Scanner(System.in);
			ChucNang tv = new ChucNang();
			Docfile df = new Docfile(pt);
			Docfile df_ton = new Docfile(pt_ton);
			Boolean kt = true;
			ArrayList<String> check = (ArrayList<String>) df.DocFiletxt();// kiểu đọc file đang ở dạng list ,nên ép kiểu
			String id;															// thành arraylist để dùng Arraylist
			//bắt nhập đúng kiểu mã sách của thư viện
			while(true)
			{
				System.out.print("Nhập mã sách(MSVN): ");
				id = sc.nextLine();
				if(id.toLowerCase().contains("msvn"))
				{
					break;
				}
				System.out.println("Mã sách bắt đầu bằng (MSVN) vì đây là mã chung của thư viện!");
			}
			System.out.print("Nhập tên sách: ");
			String name = sc.nextLine().trim();
			System.out.print("Nhập tác giả của sách: ");
			String tacgia = sc.nextLine().trim();
			System.out.print("Nhập năm xuất bản sách: ");
			int namxuatban = sc.nextInt();
			System.out.println("Số lượng sách nhập vào : ");
			int soLuong = sc.nextInt();
			HangTon ht = new HangTon(id, soLuong);
			//id là khóa chính nên sẽ kiểm tra xem có bị chùng với id đã có trong ds không , nếu có thì không add thêm vào thư viện
			df_ton.GhiFile(ht.toString());
			for (String c : check) {
				if (id.toLowerCase().equals(tv.MaId(c).toLowerCase())) {//chuyển hết về chữ thường để so sánh
					kt = false;
				}
			}
			if (kt == true) {
				Sach s = new Sach(id, name, tacgia, namxuatban);
				df.GhiFile(s.toString1());
				System.out.println("thêm thành công !");
			} else {
				sc.nextLine();
				System.out.println("mã sách đã tồn tại!\n nhập lại>>>>>>");
			}
		} catch (Exception e) {
			// bắt lỗi khi nhập không đúng kiểu dữ liệu đầu vào
			System.out.println("Lỗi!");
		}
	}

	public void SuaThongTinSach(String pt) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhâp id sách cần sửa: ");
		String maID = sc.nextLine().trim();
		ChucNang tv = new ChucNang();
		Docfile df = new Docfile(pt);
		ArrayList<String> check = (ArrayList<String>) df.DocFiletxt();
		Boolean kt = false;//tạo biến kiểm tra
		int count = 0;
		// tìm kiếm và in thông tin sách muốn sửa
		for (String c : check) {
			String[] list = c.split(",");
			if (maID.toLowerCase().equals(tv.MaId(c).toLowerCase())) {
				System.out.println("Thông tin sách cần sửa: ");
				System.out.format("%-15s %-40s %-30s %-7s \n", "|MÃ SÁCH", "TÊN SÁCH", "TÊN TÁC GIẢ", "NĂM XUẤT BẢN");
				System.out.println("|--------------------------------------------------------------------------------------------------------|");
				System.out.format("%-15s %-40s %-30s %-7s \n", "|" + list[0],list[1],list[2],list[3]);
				System.out.println("|--------------------------------------------------------------------------------------------------------|");
				kt = true;//
				break;
			}
			count++;
		}
		if (kt == true) {
			System.out.print("Sửa tên sách: ");
			String name = sc.nextLine().trim();
			System.out.print("Sửa tác giả của sách: ");
			String tacgia = sc.nextLine().trim();
			System.out.print("Sửa năm xuất bản sách: ");
			try {
				int namxuatban = sc.nextInt();
				Sach sh = new Sach(maID, name, tacgia, namxuatban);
				check.set(count, sh.toString1());
				df.SuaFile("");
				for (String c : check) {
					df.GhiFile(c);
				}
				System.out.println("Sửa thành công!");
			} catch (Exception e) {
				sc.nextLine();
				System.out.println("Lỗi!");
			}
		} else {
			System.out.println("Không tim thấy thông tin sách cần sửa");
		}
	}

	public void LkDanhSachSvMuonSach(String pt) {
		ChucNang tv = new ChucNang();
		Docfile df = new Docfile(pt);
		System.out.format("%-10s %-20s %-20s %-15s \n", "|Mã sách", "Mã sinh viên", "Tên sinh viên", "Sđt          |");
		System.out.println("|-----------------------------------------------------------------|");
		ArrayList<String> check = (ArrayList<String>) df.DocFiletxt();
		String kList = "";
		int count = 0;
		for (String c : check) {
			kList += c + ";";
			count++;
		}

		String[] listList = kList.split(";");
		for (int i = 0; i < count; i++) {
			if (!listList[i].equals("")) {
				String[] list = listList[i].split(",");
				String msach = list[0];
				String mssv = list[1];
				String tenSv = list[2];
				String sdt = list[3];
				System.out.format("%-10s %-20s %-20s %-15s \n", "|" + msach, mssv, tenSv, sdt);
				System.out.println("|-----------------------------------------------------------------|");
			}
		}
	}

	public void XoaSachTrongThuVien(String pt, String pt_ton) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập dữ liệu sách cần xóa khỏi thu viện : ");
		System.out.print("Nhập mã sách : ");
		String msach = sc.nextLine();
		ChucNang tv = new ChucNang();
		Docfile df = new Docfile(pt);
		Docfile df_ht = new Docfile(pt_ton);
		ArrayList<String> ds_ht = (ArrayList<String>) df_ht.DocFiletxt();
		ArrayList<String> ds = (ArrayList<String>) df.DocFiletxt();
		boolean check = false;
		// kt sách cần xóa có trong thư viện không
		for (String c : ds) {
			if (msach.toLowerCase().equals(tv.MaId(c).toLowerCase())) {
				check = true;
			}
		}
		// xóa dữ liệu sách bị xóa trong file sách 
		for (String c : ds) {
			String[] list = c.split(",");
			if (msach.toLowerCase().equals(tv.MaId(c).toLowerCase())) {
				System.out.println("Sách muốn xóa :");
				System.out.format("%-15s %-40s %-30s %-7s \n", "|MÃ SÁCH", "TÊN SÁCH", "TÊN TÁC GIẢ", "NĂM XUẤT BẢN");
				System.out.println("|--------------------------------------------------------------------------------------------------------|");
				System.out.format("%-15s %-40s %-30s %-7s \n", "|" + list[0],list[1],list[2],list[3]);
				System.out.println("|--------------------------------------------------------------------------------------------------------|");
			} 
		}
		System.out.println("Bạn có thực sự muốn xóa :");
		System.out.println("|-------------------|");
		System.out.println("| 1 -Có  / 2 -Không |");
		System.out.println("|-------------------|");
		System.out.println("chọn---->");
		int x = sc.nextInt();
		if(x == 1)
		{
			df_ht.SuaFile(null);
			df.SuaFile(null);
			// xóa dữ liêu sách bị xóa bên file hàng tồn
			for (String c : ds_ht) {
				if (!msach.toLowerCase().equals(tv.MaId(c).toLowerCase())) {
					df_ht.GhiFile(c);
				}
			}
			for(String c : ds)
			{
				if (!msach.toLowerCase().equals(tv.MaId(c).toLowerCase())) {
					df.GhiFile(c);
				}
			}
		}else if(x == 2){
			System.out.println("Thank you for using the service!");
		}
		if (check == true && x == 1) {
			System.out.println("Xóa thành công !");
		} else if(check == false){
			System.out.println("Không tìm thấy thông tin sách muốn xóa !");
		}

	}

	public void LietKeDanhSachHangTon(String pt) {
		Docfile df = new Docfile(pt);
		ChucNang tv = new ChucNang();
		ArrayList<String> dst = (ArrayList<String>) df.DocFiletxt();
		System.out.format("%-10s %-10s \n", "|Mã sách", "Số sách còn trong thư viện|");
		System.out.println("|------------------------------------|");
		String kList = "";
		int count = 0;
		for (String c : dst) {
			kList += c + ";";
			count++;
		}

		String[] listList = kList.split(";");
		for (int i = 0; i < count; i++) {
			if (!listList[i].equals("")) {

				String[] list = listList[i].split(",");

				String msach = list[0];
				String soLuong = list[1];
				System.out.format("%-20s %-10s \n", "|" + msach, soLuong);
				System.out.println("|------------------------------------|");
			}
		}

	}

	public void BoSungSoLuong(String pt) {
		try {

			System.out.print("Nhập mã sách cần bổ sung : ");
			Scanner sc = new Scanner(System.in);
			String maSach = sc.nextLine();
			System.out.print("Nhập số lượng cần bổ sung : ");
			int soLuong = sc.nextInt();
			ChucNang tv = new ChucNang();
			Docfile df = new Docfile(pt);
			ArrayList<HangTon> Ht = new ArrayList<HangTon>();
			ArrayList<String> dsHt = (ArrayList<String>) df.DocFiletxt();
			boolean check = false;
			for (String c : dsHt) {
				if (maSach.equals(tv.MaId(c))) {
					check = true;
				}
				int num = Integer.parseInt(tv.Phay2(c));
				HangTon sht = new HangTon(tv.MaId(c), num);
				Ht.add(sht);

			}
			df.SuaFile(null);
			for (HangTon c : Ht) {
				if (maSach.equals(c.maSach)) {
					c.SoLuong += soLuong;
				}
				df.GhiFile(c.toString());
			}
			if (check) {
				System.out.println("Bổ sung thành công");
			} else {
				System.out.println("Không tim thấy mã sách để bổ sung!");
			}

		} catch (Exception e) {
			System.out.println("Error!");
		}
	}

	public void muonSach(String pt, String pt_ton, String pt_sv) {
		try {

			Docfile df = new Docfile(pt);
			Docfile df_sv = new Docfile(pt_sv);
			Docfile df_ton = new Docfile(pt_ton);
			ChucNang cn = new ChucNang();
			Scanner sc = new Scanner(System.in);
			ArrayList<String> dsNguoi = (ArrayList<String>)df_sv.DocFiletxt();
			ArrayList<HangTon> Ht = new ArrayList<HangTon>();
			ArrayList<String> dsHt = (ArrayList<String>) df_ton.DocFiletxt();
			boolean kt_sl = true;
			boolean check = false;
			System.out.print("Mã Sách : ");
			String mSach = sc.nextLine();
			ArrayList<String> ds_sach = (ArrayList<String>) df.DocFiletxt();
			for (String c : ds_sach) {
				String[] list = c.split(",");
				if (mSach.toLowerCase().equals(cn.MaId(c).toLowerCase())) {
					check = true;
					System.out.println("Bạn có muốn mượn : ");
					System.out.format("%-15s %-40s %-30s %-7s \n", "|MÃ SÁCH", "TÊN SÁCH", "TÊN TÁC GIẢ", "NĂM XUẤT BẢN");
					System.out.println("|--------------------------------------------------------------------------------------------------------|");
					System.out.format("%-15s %-40s %-30s %-7s \n", "|" + list[0],list[1],list[2],list[3]);
					System.out.println("|--------------------------------------------------------------------------------------------------------|");
				}
			}
			if(check)
			{	
				System.out.println();
				System.out.println("|-------------------|");
				System.out.println("| 1 -Có  / 2 -Không |");
				System.out.println("|-------------------|");
				System.out.print("chọn---->");
				int kt = sc.nextInt();
				String z = sc.nextLine();
				for (String c : dsHt) {
					int num = Integer.parseInt(cn.Phay2(c));
					HangTon sht = new HangTon(cn.MaId(c), num);
					if (sht.SoLuong == 0) {
						kt_sl = false;
					}
					Ht.add(sht);
				}
				if (kt == 1 && kt_sl == true) {
					System.out.println("Nhập thông tin người mượn:");
					System.out.print("-Nhập họ tên : ");
					String name = sc.nextLine();
					System.out.print("Nhập sđt cá nhân (+84): ");
					long sdt = sc.nextLong();
					System.out.print("Nhập số ngày mượn :");
					int soNgay = sc.nextInt();
					Random rd = new Random();
					boolean kt_trung = false;
					int id;
					while(true)
					{
						id = rd.nextInt(900000);
						id += 100000;//tạo id cho người mượn có 6 chữ số
						if(isFileEmpty(pt_sv))
						{
							break;
						}
						for(String c : dsNguoi)
						{
							String[] list = c.split(",");
							int idCheck = Integer.valueOf(list[0]);
							if(id == idCheck)
							kt_trung = true;
						}
						if(kt_trung == false)
						{
							break;
						}
					}
					System.out.println("Id của bạn là : " + id);
					// Tạo một đối tượng Date hiện tại
					Date currentDate = new Date();
					// Tạo định dạng cho ngày tháng
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
					// Chuyển đổi đối tượng Date thành chuỗi String theo định dạng
					String ngayMuon = dateFormat.format(currentDate);
					 Calendar calendar = Calendar.getInstance();
				     calendar.setTime(currentDate);
				     calendar.add(Calendar.DATE,soNgay);// cộng thêm số ngày mượn
				     Date newDate = calendar.getTime();
					String ngayTra = dateFormat.format(newDate);
					SinhVien sv = new SinhVien(mSach.toUpperCase(),String.valueOf(id), name, sdt, ngayMuon, ngayTra);
					df_sv.GhiFile(sv.toString());
					df_ton.SuaFile(null);
					for (String c : dsHt) {

						int num = Integer.parseInt(Phay2(c));
						if (mSach.toLowerCase().equals(MaId(c).toLowerCase())) {
							num -= 1;
						}
						HangTon ht = new HangTon(MaId(c), num);
						df_ton.GhiFile(ht.toString());
					}

					System.out.println("Đăng kí mượn thành công !");
				} else if (kt == 2) {
					System.out.println("Thank you for using the service!");
				} else if (check == false) {
					System.out.println("Không tồn tại mã sách cần mượn!");
				} else if (kt_sl == false) {
					System.out.println("Không còn sách để mượn!");
				}
				
				else {
					System.out.println("Error!");
				}
				
			}else {
				System.out.println("Không tìm thấy thông tin sách !");
			}
		} catch (Exception e) {
			System.out.println("Error!");
		}
	}

	public void traSach(String pt, String pt_sv, String pt_ton) {
		try {
			Docfile df = new Docfile(pt);
			Docfile df_sv = new Docfile(pt_sv);
			Docfile df_ton = new Docfile(pt_ton);
			ChucNang tv = new ChucNang();
			Scanner sc = new Scanner(System.in);
			ArrayList<String> ds = (ArrayList<String>) df.DocFiletxt();
			ArrayList<String> ds_sv = (ArrayList<String>) df_sv.DocFiletxt();
			ArrayList<String> ds_ton = (ArrayList<String>) df_ton.DocFiletxt();
			System.out.print("Nhập id :");
			int mso = sc.nextInt();
			String msach = null;
			boolean check = false;
			df_sv.SuaFile(null);
			String kt_Han = null;
			for (String c : ds_sv) {
				String[] list = c.split(",");
				if (mso == Integer.valueOf(MaId(c))) {
					check = true;
					msach = Phay2(c);
					System.out.println("Sinh viên trả sách : ");
					System.out.format("|%-10s %-15s %-20s %-15s %-20s %-20s \n", "ID", "Mã sách mượn", "Tên người mượn", "Sđt","Ngày Mượn" ,"Hạn Ngày Trả");
					System.out.println("|---------------------------------------------------------------------------------------------------|");
					System.out.format("|%-10s %-15s %-20s %-15s %-20s %-20s \n",list[0],list[1],list[2],list[3],list[4],list[5]);
					System.out.println("|---------------------------------------------------------------------------------------------------|");
					kt_Han = list[5];
				} else {
					df_sv.GhiFile(c);
				}
			}
			// Tạo một đối tượng Date hiện tại
			Date currentDate = new Date();
			// Tạo định dạng cho ngày tháng
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			// Chuyển đổi đối tượng Date thành chuỗi String theo định dạng
			String NgayTra = dateFormat.format(currentDate);
			if (check == true) {
				df_ton.SuaFile(null);
				ArrayList<HangTon> ds_ht = new ArrayList<HangTon>();
				for (String c : ds_ton) {

					int num = Integer.parseInt(tv.Phay2(c));
					if (msach.toLowerCase().equals(tv.MaId(c).toLowerCase())) {
						num += 1;
					}
					HangTon ht = new HangTon(tv.MaId(c), num);
					df_ton.GhiFile(ht.toString());
				}
				if(SoSanhDate(kt_Han, NgayTra) < 0)
				{
					System.out.println("Cảnh cáo quá hạn trả sách!");
				}
				System.out.println("Trả thành công !");
			} else {
				System.out.println("Không tìm thấy thông tin người mượn sách!");
			}
		} catch (Exception e) {
		}
	}

	public Boolean Dangki() {
		boolean kt = true;
		QuanLiFile ql = new QuanLiFile();
		try {
			ChucNang tv = new ChucNang();
			Docfile df = new Docfile(ql.getfDsTaiKhoanTv());
			Scanner sc = new Scanner(System.in);
			String tk_tk;
			String mk_tk;
			while (true) {
				System.out.print("Tài khoản : ");
				tk_tk = sc.nextLine();
				if (tk_tk.length() >= 5) {
					break;
				}
				System.out.println("Tài khoản phải ít nhất 5 kí tự");
			}
			while (true) {
				System.out.print("Mật khẩu : ");
				mk_tk = sc.nextLine();
				if (mk_tk.length() >= 5) {
					break;
				}
				System.out.println("Mật khẩu phải ít nhất 5 kí tự");
			}
			//bắt buộc tk mk phải có ít nhất 5 kí tự
			System.out.print("Sđt : (+84)");
			long sdt = sc.nextLong();
			TaiKhoan tk = new TaiKhoan(tk_tk, mk_tk, sdt);
			ArrayList<String> check = (ArrayList<String>) df.DocFiletxt();
			for (String c : check) {
				if (tv.MaId(c).equals(tk.getTk())) {//kt không cho trung tài khoản đăng nhập
					System.out.println("Tài khoản đã tồn tại!");
					kt = false;
					return false;
				}
				String[] list = c.split(",");
				if (list[2].equals(String.valueOf(sdt))) {//kt không cho trùng số đt
					System.out.println("Sđt đã được đăng kí !");
					kt = false;
					return false;
				}
			}
			df.GhiFile(tk.toString());
			System.out.println("Đăng kí thành công !");
			return true;
		} catch (Exception e) {
			System.out.println("Error!");
		}
		return kt;
	}

	public String Dangnhap() {
		QuanLiFile ql= new QuanLiFile();
		String kt = "";
		TaiKhoan tkk = new TaiKhoan(null, null, 0);
		ChucNang tv = new ChucNang();
		Docfile df = new Docfile(ql.getfDsTaiKhoanTv());
		Scanner sc = new Scanner(System.in);
		System.out.print("Tài khoản : ");
		String tk_tk = sc.nextLine();
		System.out.print("Mật khẩu : ");
		String mk_tk = sc.nextLine();
		boolean check = true;
		Docfile df_tkAD = new Docfile(ql.getfDsTaiKhoanAd());
		ArrayList<String> dsTKAD = (ArrayList<String>)df_tkAD.DocFiletxt();//tạo arraylist chứ ds các tài khoản đã đăng kí từ trc
		for(String c : dsTKAD)
		{
			String[] list = c.split(",");
			if(tk_tk.equals(list[0]) && mk_tk.equals(list[1]))
			{
				return "ADMIN";
			}
		}
		String tk = "";
		String mk = "";
		ArrayList<String> ds_tk = (ArrayList<String>) df.DocFiletxt();
		for (String c : ds_tk) {
			String[] list = c.split(",");
			tk = list[0];
			mk = list[1];
			if (tk.equals(tk_tk) && mk.equals(mk_tk)) {
				return "nguoi_dung";
			} else {
				check = false;
			}
		}
		if (check == false) {
			System.out.println("Thông tin tài khoản , mật khẩu không chính xác!");
		}
		return null;
	}

	public void QuenMatKhau() {
		QuanLiFile ql = new QuanLiFile();
		Docfile df = new Docfile(ql.getfDsTaiKhoanTv());
		Scanner sc = new Scanner(System.in);
		boolean kt = false;//biến kiểm tra xem có tồn tại thông tin không
		try {
			System.out.print("Nhập sdt bạn đăng kí : (+84)");
			long sdt = sc.nextLong();
			ArrayList<String> ds_tk = (ArrayList<String>) df.DocFiletxt();
			for (String c : ds_tk) {
				String[] list = c.split(",");
				if (list[2].equals(String.valueOf(sdt))) {//so sánh sdt trong file để tìm tk mk
					System.out.println("Tài khoản : " + list[0]);
					System.out.println("Mật khẩu  : " + list[1]);
					kt = true;
				}
			}
			if (kt == false) {
				System.out.println("Không tìm thấy thông tin tài khoản !");
			}
		} catch (Exception e) {
			System.out.println("ERROR!");
		}
	}
	public String TimKiem(String pt)
	{
		Docfile df = new Docfile(pt);
		Scanner sc = new Scanner(System.in);
		ArrayList<String> dsSach = (ArrayList<String>)df.DocFiletxt();
		System.out.println("Nhập tên sách hoặc mã sách(MSVN) muốn tìm kiêm : ");
		String tmSach = sc.nextLine();
		String mSach = "";
		String tSach = "";
		boolean kt = false;
		if(tmSach.toLowerCase().contains("msvn"))
		{
			System.out.println("Thông tin sách cần tìm: ");
			System.out.println("|--------------------------------------------------------------------------------------------------------|");
			System.out.format("%-15s %-40s %-30s %-7s \n", "|MÃ SÁCH", "TÊN SÁCH", "TÊN TÁC GIẢ", "NĂM XUẤT BẢN");
			System.out.println("|--------------------------------------------------------------------------------------------------------|");
			for(String c : dsSach)
			{
				String[] list = c.split(",");
			
				if(tmSach.toLowerCase().equals(list[0].toLowerCase()))
				{
					System.out.format("%-15s %-40s %-30s %-7s \n", "|" + list[0],list[1],list[2],list[3]);
					System.out.println("|--------------------------------------------------------------------------------------------------------|");
					kt = true;
				}
			}
			if(kt == false)
			{
				System.out.println("|Không tìm thấy sách !");
				System.out.println("|--------------------------------------------------------------------------------------------------------|");
				return null;
			}
		}else
		{
			System.out.println("Thông tin sách có liên quan : ");
			System.out.println("|--------------------------------------------------------------------------------------------------------|");
			System.out.format("%-15s %-40s %-30s %-7s \n", "|MÃ SÁCH", "TÊN SÁCH", "TÊN TÁC GIẢ", "NĂM XUẤT BẢN");
			System.out.println("|--------------------------------------------------------------------------------------------------------|");
			for(String c : dsSach)
			{
				String[] list = c.split(",");
				if((list[1].toLowerCase()).contains(tmSach.toLowerCase()))//kiểm tra xem kí tự có tồn tại trong String không
				{
					System.out.format("%-15s %-40s %-30s %-7s \n", "|" + list[0],list[1],list[2],list[3]);
					System.out.println("|--------------------------------------------------------------------------------------------------------|");
					kt = true;
				}
			}
			if(kt == false)
			{
				System.out.println("|Không tìm thấy sách !");
				System.out.println("|--------------------------------------------------------------------------------------------------------|");
				return null;
			}
		}
		return null;
	}
	public void TimKiemNguoiMuon(String pt)
	{
		Docfile df = new Docfile(pt);
		ArrayList<String> ds_nguoiMuon =(ArrayList<String>) df.DocFiletxt();
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập mã sách : ");
		String mSach = sc.nextLine();
		System.out.println("Danh sách sinh viên : ");
		System.out.format("|%-10s %-15s %-20s %-15s %-20s %-20s \n", "ID", "Mã sách mượn", "Tên người mượn", "Sđt","Ngày Mượn" ,"Hạn Ngày Trả");
		System.out.println("|---------------------------------------------------------------------------------------------------|");
		boolean kt = false;//tạo biến kt xem có tồn tại người mượn hay không
		for(String c : ds_nguoiMuon)
		{
			String[] list = c.split(",");
			if(mSach.toLowerCase().equals(list[1].toLowerCase()))//chuyển hết về kí tự thường để so sánh
			{
				kt = true;
				System.out.format("|%-10s %-15s %-20s %-15s %-20s %-20s \n",list[0],list[1],list[2],list[3],list[4],list[5]);
				System.out.println("|---------------------------------------------------------------------------------------------------|");
			}
		}
		if(kt == false)
		{
			System.out.println("|Không thấy người mượn sách !");
			System.out.println("|---------------------------------------------------------------------------------------------------|");
		}
	}
}
