package quanlithuvien;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class Docfile {
	public String path;
	Docfile(String path)
	{
		this.path = path;
	}
	public void GhiFile(String sach) {
		try {
			FileWriter writer = new FileWriter(path, true);
			writer.write(sach + "\n");
			writer.close();
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	public List<String> DocFiletxt()
	{
		File f = new File(path);
		List<String> arr,brr;
		try {
			
			arr = Files.readAllLines(f.toPath(),StandardCharsets.UTF_8);
			return arr;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public void SuaFile(String sach) {
		try {
			FileWriter writer = new FileWriter(path);
			writer.write("");
			writer.close();
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}


}
