package quanlithuvien;

import java.util.Date;

public class SinhVien {
	private String id;
	private String idSachMuon;
	private String name;
	private long sdt;
	private String ngayMuon;
	private String ngayTra;
	SinhVien(String idSachMuon,String id, String name,long sdt,String ngayMuon, String ngayTra)
	{
		this.id = id;
		this.idSachMuon = idSachMuon;
		this.name = name;
		this.ngayMuon = ngayMuon;
		this.ngayTra = ngayTra;
		this.sdt = sdt;
	}
	public String getIdSachMuon() {
		return idSachMuon;
	}
	public void setIdSachMuon(String idSachMuon) {
		this.idSachMuon = idSachMuon;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getSdt() {
		return sdt;
	}
	public void setSdt(long sdt) {
		this.sdt = sdt;
	}
	public String getNgayMuon() {
		return ngayMuon;
	}
	public void setNgayMuon(String ngayMuon) {
		this.ngayMuon = ngayMuon;
	}
	public String getNgayTra() {
		return ngayTra;
	}
	public void setNgayTra(String ngayTra) {
		this.ngayTra = ngayTra;
	}
	public String toString() {
		return id+","+idSachMuon +"," + name + "," + sdt+","+ngayMuon + ","+ngayTra;
	}
	
}
