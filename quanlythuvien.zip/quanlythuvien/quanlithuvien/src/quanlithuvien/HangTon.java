package quanlithuvien;

public class HangTon {
	public String maSach;
	public int SoLuong;
	HangTon(String maSach , int SoLuong)
	{
		this.maSach = maSach;
		this.SoLuong = SoLuong;
	}
	public String getMaSach() {
		return maSach;
	}
	public void setMaSach(String maSach) {
		this.maSach = maSach;
	}
	public int getSoLuong() {
		return SoLuong;
	}
	public void setSoLuong(int soLuong) {
		SoLuong = soLuong;
	}
	@Override
	public String toString() {
		return  maSach+","+SoLuong;
	}
	
}
